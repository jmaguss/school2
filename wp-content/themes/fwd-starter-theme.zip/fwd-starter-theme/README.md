FWD Starter Theme
===

A starter theme for the FWDP 3600 course (Content Management Systems) of the Front-end Web Developer program at BCIT.

Installation
---------------

### Requirements

- Tested up to: 5.8
- Requires PHP: 7.0
- License: GNU General Public License v2 or later
- License URI: LICENSE

### Quick Start

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.